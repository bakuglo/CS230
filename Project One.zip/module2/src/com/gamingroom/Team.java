package com.gamingroom;

import java.util.ArrayList;
/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 * with code from Dylan Bishop
 */
public class Team extends Entity {
	
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	public Player addPlayer(String name) {
		Player tempPlayer = null;
		
	//creating a loop to search the list of players
		for (Player currPlayer : players) {
			if (currPlayer.name.equalsIgnoreCase(name)) { //checking if the player name is already added
				// if so, return current player
				return currPlayer;
			}
		}
		//Because there was no player found, create the new player
		//Call to the GameService to get the new PlayerID
		GameService tempService = GameService.getGameService();
		
		tempPlayer = new Player(tempService.getNextPlayerId(), name);
		
		//adding the player to the list of players that are on the team
		players.add(tempPlayer);
		
		return tempPlayer;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
