package com.gamingroom;

// A simple Superclass to hold all of the players, teams, and game entites.
// @author Dylan Bishop
// November 12, 2023
public class Entity {

	// setting attributes to protected so the subclasses can inherit them
	protected long id;
	protected String name;
	
	@SuppressWarnings("unused")
	protected Entity() {}
	
	public Entity(long id, String name) {
		
		this.id = id;
		this.name = name;
	}
	
	public long getId() {
		return id;
	}
	
	pulic String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]"
	}
	
 }
